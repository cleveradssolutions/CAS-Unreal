//
//  CASUBridge.h
//  CASUBridge
//
//  Copyright © 2025 CleverAdsSolutions LTD, CAS.AI. All rights reserved.
//

#import <CleverAdsSolutions/CleverAdsSolutions-Swift.h>
#import <CleverAdsSolutions/CleverAdsSolutions.h>
#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface CASUBridge : NSObject

- (instancetype)initWithId:(NSString *)casId
             engineVersion:(NSString *)engineVersion;

- (const char *)getMobileAdsVersion;

#pragma mark - Initialize

- (BOOL)isInitializedAds;

- (void)initializeAds;

- (void)setAutoloadFormatsWith:(BOOL)isBannerUsed
                      withMRec:(BOOL)isMRecUsed
                     withInter:(BOOL)isInterUsed
                    withReward:(BOOL)isRewardUsed;

- (void)setTestAdModeForInit;

- (void)setInitializationExtras:(NSString *)value forKey:(NSString *)key;

- (void)setMetaAdvertiserTrackingEnabled:(BOOL)enabled;

- (void)setMetaDataProcessingOptions:(int)options;

- (void)setConsentFlowEnabled:(BOOL)isEnabled
                    geography:(int)geography
                   privacyURL:(NSString *)privacyURL
                   controller:(UIViewController *)controller;

- (const char *)getInitializationError;

- (const char *)getUserCountryCode;

- (int)getUserConsentForAds;

- (int)getUserConsentFlowStatus;

- (BOOL)isUserConsentRequired;

#pragma mark - Settings

- (void)setVerboseAdsLogs:(BOOL)enabled;

- (void)setAdsMuted:(BOOL)mute;

- (void)setUserAudienceForAds:(int)audience;

- (void)setUserConsentForAds:(int)consentStatus;

- (void)setUserOptOutSaleForAds:(int)ccpStatus;

- (void)setUserID:(NSString *)userID;

- (void)setUserAgeForAds:(int)userAge;

- (void)setUserGenderForAds:(int)userGender;

- (void)setUserLocationCollectionForAds:(BOOL)enabled;

- (void)setTestDeviceIds:(NSArray<NSString *> *)deviceIds;

- (void)setTrialAdFreeInterval:(int)interval;

- (void)showConsentFlowIfRequired:(BOOL)ifRequired
                       controller:(UIViewController *)controller;

- (void)validateAdsIntegration;

#pragma mark - Banner Ads

- (BOOL)isBannerAdReady;

- (void)loadBannerAd:(int)adSize mainView:(UIView *)mainView;

- (void)showBannerAd;

- (void)hideBannerAd;

- (void)setAutoloadBannerAd:(BOOL)enabled;

- (void)setBannerAdPosition:(int)adPosition withX:(int)x withY:(int)y;

- (void)setBannerAdRefreshInterval:(int)interval;

- (void)destroyBannerAd;

#pragma mark - MRec Ads

- (BOOL)isMRecAdReady;

- (void)loadMRecAd:(UIView *)mainView;

- (void)showMRecAd;

- (void)hideMRecAd;

- (void)setAutoloadMRecAd:(BOOL)enabled;

- (void)setMRecAdPosition:(int)adPosition withX:(int)x withY:(int)y;

- (void)setMRecAdRefreshInterval:(int)interval;

- (void)destroyMRecAd;

#pragma mark - Interstitial Ads

- (void)loadInterstitialAd;

- (BOOL)isInterstitialAdReady;

- (void)showInterstitialAd:(UIViewController *)controller;

- (void)setAutoloadInterstitialAd:(BOOL)enabled;

- (void)setAutoshowInterstitialAdEnabled:(BOOL)enabled;

- (void)setInterstitialAdMinimumInterval:(int)interval;

- (void)restartInterstitialAdInterval;

- (void)destroyInterstitialAd;

#pragma mark - Rewarded Ads

- (void)loadRewardedAd;

- (BOOL)isRewardedAdReady;

- (void)showRewardedAd:(UIViewController *)controller;

- (void)setAutoloadRewardedAd:(BOOL)enabled;

- (void)destroyRewardedAd;

#pragma mark - AppOpen Ads

- (void)loadAppOpenAd;

- (BOOL)isAppOpenAdReady;

- (void)showAppOpenAd:(UIViewController *)controller;

- (void)setAutoloadAppOpenAd:(BOOL)enabled;

- (void)setAutoshowAppOpenAdEnabled:(BOOL)enabled;

- (void)destroyAppOpenAd;


#pragma mark - Impression

- (float)getImpressionCPMFor:(int)adType;
- (const char *)getImpressionNetworkFor:(int)adType;
- (const char *)getImpressionAdUnitFor:(int)adType;
- (const char *)getImpressionCreativeFor:(int)adType;
- (int)getImpressionDepthFor:(int)adType;
- (float)getImpressionLifetimeRevenueFor:(int)adType;

@end

NS_ASSUME_NONNULL_END
