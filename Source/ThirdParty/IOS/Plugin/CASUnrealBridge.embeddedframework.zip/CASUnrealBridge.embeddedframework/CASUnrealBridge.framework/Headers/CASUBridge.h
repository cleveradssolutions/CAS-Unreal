//
//  CASUBridge.h
//  CASUBridge
//
//  Created by Денис Ешенко on 04.01.2024.
//  Copyright © 2024 CleverAdsSolutions LTD, CAS.AI. All rights reserved.
//

#import <CleverAdsSolutions/CleverAdsSolutions-Swift.h>
#import <CleverAdsSolutions/CleverAdsSolutions.h>
#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface CASUBridge : NSObject

- (instancetype)initWithId:(NSString *)casId
             engineVersion:(NSString *)engineVersion;

- (const char *)getMobileAdsVersion;

#pragma mark - Initialize

- (BOOL)isInitializedAds;

- (void)initializeAds;

- (void)setAutoloadFormatsWith:(BOOL)isBannerUsed
                      withMRec:(BOOL)isMRecUsed
                     withInter:(BOOL)isInterUsed
                    withReward:(BOOL)isRewardUsed;

- (void)setTestAdModeForInit;

- (void)setInitializationExtras:(NSString *)value forKey:(NSString *)key;

- (void)setMetaAdvertiserTrackingEnabled:(BOOL)enabled;

- (void)setMetaDataProcessingOptions:(int)options;

- (void)setConsentFlowEnabled:(BOOL)isEnabled
                    geography:(int)geography
                   privacyURL:(NSString *)privacyURL
                   controller:(UIViewController *)controller;

- (const char *)getInitializationError;

- (const char *)getUserCountryCode;

- (int)getUserConsentForAds;

#pragma mark - Settings

- (void)setVerboseAdsLogs:(BOOL)enabled;

- (void)setAdsMuted:(BOOL)mute;

- (void)setUserAudienceForAds:(int)audience;

- (void)setUserConsentForAds:(int)consentStatus;

- (void)setUserOptOutSaleForAds:(int)ccpStatus;

- (void)setUserAgeForAds:(int)userAge;

- (void)setUserGenderForAds:(int)userGender;

- (void)setUserLocationCollectionForAds:(BOOL)enabled;

- (void)setTestDeviceIds:(NSArray<NSString *> *)deviceIds;

- (void)setTrialAdFreeInterval:(int)interval;

- (void)showConsentFlowIfRequired:(BOOL)ifRequired
                       controller:(UIViewController *)controller;

- (void)validateAdsIntegration;

#pragma mark - Banner Ads

- (BOOL)isBannerAdReady;

- (void)loadBannerAd:(int)adSize mainView:(UIView *)mainView;

- (void)showBannerAd;

- (void)hideBannerAd;

- (void)setBannerAdPosition:(int)adPosition withX:(int)x withY:(int)y;

- (void)setBannerAdRefreshInterval:(int)interval;

- (void)destroyBannerAd;

#pragma mark - MRec Ads

- (BOOL)isMRecAdReady;

- (void)loadMRecAd:(UIView *)mainView;

- (void)showMRecAd;

- (void)hideMRecAd;

- (void)setMRecAdPosition:(int)adPosition withX:(int)x withY:(int)y;

- (void)setMRecAdRefreshInterval:(int)interval;

- (void)destroyMRecAd;

#pragma mark - Interstitial Ads

- (void)loadInterstitialAd;

- (BOOL)isInterstitialAdReady;

- (void)showInterstitialAd:(UIViewController *)controller;

- (void)setInterstitialAdMinimumInterval:(int)interval;

- (void)restartInterstitialAdInterval;

#pragma mark - Rewarded Ads

- (void)loadRewardedAd;

- (BOOL)isRewardedAdReady;

- (void)showRewardedAd:(UIViewController *)controller;

#pragma mark - Return To App Ads

- (void)showAdOnReturnToApp;

- (void)skipAdOnNextReturnToApp;

- (void)destroyReturnToAppAd;

#pragma mark - Impression

- (float)getImpressionCPMFor:(int)adType;
- (const char *)getImpressionNetworkFor:(int)adType;
- (const char *)getImpressionAdUnitFor:(int)adType;
- (const char *)getImpressionCreativeFor:(int)adType;
- (int)getImpressionDepthFor:(int)adType;
- (float)getImpressionLifetimeRevenueFor:(int)adType;

#pragma mark - Plugin Utils

+ (int)getNumberFromEnumError:(enum CASError)error;
+ (int)getNumberFromError:(NSString *)error;

@end

NS_ASSUME_NONNULL_END
