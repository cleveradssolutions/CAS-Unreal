/*
 * Version for iOS © 2022 YANDEX
 *
 * You may not use this file except in compliance with the License.
 * You may obtain a copy of the License at https://yandex.com/legal/mobileads_sdk_agreement/
 */

#import <Foundation/Foundation.h>




@interface YMANativeAdVideoController : NSObject



- (void)pause;

- (void)resume;

@end
