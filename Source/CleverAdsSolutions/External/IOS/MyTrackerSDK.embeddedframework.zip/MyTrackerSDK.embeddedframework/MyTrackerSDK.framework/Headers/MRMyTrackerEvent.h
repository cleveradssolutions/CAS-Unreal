//
//  MRMyTrackerEvent.h
//  myTrackerSDK
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface MRMyTrackerEvent : NSObject

@property (nonatomic, readonly) int type NS_SWIFT_NAME(type);

@end

NS_ASSUME_NONNULL_END
