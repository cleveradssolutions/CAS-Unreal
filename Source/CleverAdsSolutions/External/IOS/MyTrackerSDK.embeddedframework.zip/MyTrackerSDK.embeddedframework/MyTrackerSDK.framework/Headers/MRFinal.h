//
//  MRFinal.h
//  myTrackerSDK
//

#ifndef MRFinal_h
#define MRFinal_h

#if defined(__has_attribute) && __has_attribute(objc_subclassing_restricted)
# define MR_FINAL __attribute__((objc_subclassing_restricted))
#else
# define MR_FINAL
#endif

#endif /* MRFinal_h */
